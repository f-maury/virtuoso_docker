#!/usr/bin/env bash
set -e

# wait for Virtuoso to be ready
sleep 5

# install the VADs if not already present
isql 1111 dba "${DBA_PASSWORD}" <<SQL
    WHENEVER SQLERROR EXIT SQL.SQLCODE;
    EXEC=DB.DBA.VAD_INSTALL('cartridges_dav.vad');
    EXEC=DB.DBA.VAD_INSTALL('fct_dav.vad');
    EXEC=DB.DBA.VAD_INSTALL('rdf_mappers_dav.vad');
    COMMIT;
    EXIT;
SQL

